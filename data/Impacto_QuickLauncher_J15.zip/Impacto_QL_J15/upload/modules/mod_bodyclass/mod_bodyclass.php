<?php
/**
* @version		$Id: mod_bodyclass.php 2009-09-11
* @copyright	Copyright 2009 - 2010 SimpleThemes LLC
* @license		http://creativecommons.org/licenses/by-nc-sa/2.0/
*/
// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
$displaynav				= $params->get('displaynav');
$displayheader 		= $params->get('displayheader');
$displayfooter 		= $params->get('displayfooter');
echo $params->get('moduleclass_sfx');
if ($displaynav == "hidenav") {
echo ' '.$params->get('displaynav' );
}
if ($displayheader == "hideheader") {
echo ' '.$params->get('displayheader' );
}
if ($displayfooter == "hidefooter") {
echo ' '.$params->get('displayfooter' );
}
?>
